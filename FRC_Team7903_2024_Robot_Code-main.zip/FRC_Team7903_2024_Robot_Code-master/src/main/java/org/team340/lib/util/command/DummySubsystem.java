package org.team340.lib.util.command;

import edu.wpi.first.wpilibj2.command.Subsystem;

/**
 * A dummy subsystem. Intended to be used as a secondary mutex for the command scheduler.
 */
public final class DummySubsystem implements Subsystem {}
